python-dtxrd - Calculations using dynamical theory of x-ray diffraction
------------------------------------------------------------------------
dtxrd - calculates reflectivity and transmissivity for a given Bragg
reflection of various single crystals (C (diamond), Si, Ge and Al2O3
(sapphire)

throughput - calculates throughput for a multi-crystal configuration
described by an input file with a special format

dctopo - recombines snapshots of crystal reflectivity at different 
angles on the crystal rocking curve to produce rocking curve images 
(e.g., map of FWHM of the rocking curve, peak position, etc.)

seehdf - an hdf4 file viewer 

peak - a tool to plot and perform fitting and analysis of a rocking curve
peak data given by a multi-column ASCII file.
  
REQUIREMENTS
------------
* python-numpy
* python-scipy
* python-matplotlib
* Optik 1.3 or above OR Python 2.3's optparse module.
    http://optik.sourceforge.net


INSTALLATION
------------

The Python Distutils system provides packaging, compilation, and installation
for python-dtxrd

To install, execute the following command as superuser:
  # python setup.py install [OPTIONS]

For more information about installation options, execute the following
command:
  > python setup.py install --help

For information about other Distutils commands, execute the following command:
  > python setup.py install --help-commands


AVAILABILITY
------------

Not publically available at the moment

AUTHOR
------

python-dtxrd was written by Stanislav Stoupin <sstoupin@gmail.com>


COPYRIGHT & LICENSE
-------------------

  Copyright (C) 2014 Stanislav Stoupin

  Permission is hereby granted, free of charge, to any person obtaining
  a copy of this software and associated documentation files (the
  "Software"), to deal in the Software without restriction, including
  without limitation the rights to use, copy, modify, merge, publish,
  distribute, sublicense, and/or sell copies of the Software, and to
  permit persons to whom the Software is furnished to do so, subject to
  the following conditions:

  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
  IN NO EVENT SHALL STANISLAV STOUPIN BE LIABLE FOR ANY
  CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
  TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
  SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

  Except as contained in this notice, the name of STANISLAV STOUPIN
  shall not be used in advertising or otherwise to promote
  the sale, use or other dealings in this Software without prior written
  authorization from STANISLAV STOUPIN.
