#!/usr/bin/env python

# Name: setup.py
# Purpose: python-dtxrd distutils install program
# Author: Stanislav Stoupin <sstoupin@gmail.com>
#
# Copyright 2014
#
# See the file "LICENSE" for information on usage and redistribution
# of this file, and for a DISCLAIMER OF ALL WARRANTIES.


import distutils
from distutils.core import setup

setup(
    name = 'python-dtxrd',
    version = '1.0',
    maintainer = 'Stanislav Stoupin',
    maintainer_email = 'sstoupin@gmail.com',
    url='http://www.aps.anl.gov',
    license = 'MIT X11/XFree86 style',
    description = 'Calculations using dynamical theory of x-ray diffraction',
        package_dir = {'': 'lib'},
        packages = ['dtxrd', 'dtxrd.myio', ],
	package_data = {'dtxrd': ['asf/*.asf']},
	scripts = ['dtxrd', 'throughput', 'rctopo','seehdf','rcpeak']	
)
